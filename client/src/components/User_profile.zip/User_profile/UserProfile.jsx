import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import Modal from 'react-bootstrap/Modal'
import { Button, Toast } from 'react-bootstrap';
import PuffLoader from "react-spinners/PuffLoader";
import { FaRegUser } from "react-icons/fa";

import ProfilePic from './ProfilePic';
import PrCss from './userProfile.module.css';
import { fetchAllUsers } from '../../redux/actions/users'
import { createProfileAction, getProfileAction } from '../../redux/actions/userProfile';


function MyVerticallyCenteredModal(props) {
  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    onHide={props.onhide}
    >
      <Modal.Header closeButton  >
        <Modal.Title id="contained-modal-title-vcenter">
          <span ><FaRegUser /> About Me </span>
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <h6><b> Wow the recruiters </b></h6>
        <p>
          Imagine that you're meeting the CEO of your dream company. What should you say to amaze them?
        </p>
        <form>
          <div class="form-group">
            <textarea
              class="form-control"
              id="exampleFormControlTextarea1"
              onChange={(e) => props.setintrodesc(e.target.value)}
              placeholder='Write a short and sweet introduction about yourself to catch recruiters attention.'
              rows="3">

            </textarea>
          </div>
        </form>
      </Modal.Body>
      <Modal.Footer>
        <Button onClick={props.onhide} className='btn btn-secondary'> Close</Button>
        <Button onClick={props.submitintro}>
          {props.loading ? <>
            <div className='d-flex'> 
              <PuffLoader 
              size={25}
              color="#ffffff" 
              /> <span className='pl-2'> Submitting... </span>
            </div>
          </> : 'Submit'}
        </Button>
      </Modal.Footer>
    </Modal>
  );
}


const UserProfile = () => {

  const a = false;

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);
  const [modalShow, setModalShow] = useState(false);
  const [introdesc, setintrodesc] = useState('');
  
    // Getting current User Profile from the database
  const { id } = useParams();
  const users = useSelector((state) => state.usersReducer)
  const currentUser = users?.allUserDetails?.filter((user) => user._id === id)[0];
  console.log(currentUser);
    // Getting current User Profile from the database

  
    
  useEffect(() => {
    const storedProfile = JSON.parse(localStorage.getItem('Profile'));
    console.log("Stored profile : ", storedProfile);

    if (!storedProfile || storedProfile?.result?._id !== id || !storedProfile?.result) {
      navigate('/login');
    }

    dispatch(fetchAllUsers());
  }, [dispatch])


  useEffect(() => {
    const fetchProfile = async () => {
      const getsingleProfileData = await dispatch(getProfileAction(id));
      console.log("Get Single Profile Data : ", getsingleProfileData);
    };

    fetchProfile();
  }, [id]);


  const handleIntroduceYourself = async () => {
    setLoading(true);
    const userProfileData = {
      introduction: introdesc,
      userId:id
    }

    const repsonse = await dispatch(createProfileAction(userProfileData));

    if (repsonse.success) {
      setLoading(false)
      setModalShow(false)
      console.log("Profile Created Successfully");
    } else {
      console.log("Failed to create Profile");
    }
  }


  return (

    <div >   {/*  main container */}
      <ProfilePic />
      <div className='container'>
        <div className='row pt-2  '>
          <div className={PrCss.contactFollow}>

            <div className='card w-75'>
              <div className='card mt-5'>
                <div class="card-body ">
                  <i class="fa-solid fa-user fa-3x"></i> &nbsp;
                  <span>
                    Profile at 60% Completion
                  </span>
                </div>
              </div>
            </div>

            <div class="card" style={{ width: '23vw' }}>
              <div class="card-body text-center">
                <i class="fa-solid fa-envelope"></i> &nbsp;
                <span>
                  Contact
                </span>
              </div>
              <div class="card-body">
                <i class="fa-solid fa-at"></i> &nbsp;
                <span>
                  {currentUser?.email}
                </span>
              </div>
              <div class="card-body">
                <i class="fa-solid fa-phone"></i>&nbsp;
                <span>
                  {currentUser?.country_code} - {currentUser?.phone}
                </span>
              </div>
            </div>

          </div>
        </div>
        <div className='row'>
          {!a ?
            <>
              <div className={` ${PrCss.addSections}`} style={{ cursor: 'pointer' }} onClick={() => setModalShow(true)}>
                <div className="card w-100">
                  <div className="card-body text-center">
                    <i className='fa-solid fa-plus'></i>
                    <p className='card-text'> Briefly Introduce Yourself  </p>


                    {/* Modal Start  */}

                    {/* <button variant="primary" onClick={}> */}
                    {/* Launch vertically centered modal */}
                    {/* </button> */}

                    <MyVerticallyCenteredModal
                      show={modalShow}
                      onhide={() => setModalShow(false)}
                      submitintro={handleIntroduceYourself}
                      setintrodesc={setintrodesc}
                      loading={loading}
                    />

                    {/* Modal End */}
                  </div>
                </div>
              </div>
            </> :
            <>
              <div class="card">
                <div class="card-header">
                  About Me
                </div>
                <div class="card-body">
                  <blockquote class="blockquote mb-0">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit quod voluptas dolor fugit dolorum dicta consectetur ipsa commodi soluta laudantium facilis, error aut ipsum, quibusdam laborum incidunt inventore itaque totam eligendi quia qui deleniti. Soluta reprehenderit possimus itaque optio suscipit accusantium quaerat eos magni, cumque qui sequi et distinctio commodi?</p>
                    {/* <footer class="blockquote-footer">Someone famous in <cite title="Source Title">Source Title</cite></footer> */}
                  </blockquote>
                </div>
              </div>
            </>

          }

          <div className={` ${PrCss.addSections}`}>
            <div className="card w-100">
              <div className="card-body text-center">
                <i className='fa-solid fa-plus'></i>
                <p className='card-text'> Add your experiences  </p>
              </div>
            </div>
          </div>

          <div className={` ${PrCss.addSections}`}>
            <div className="card w-100">
              <div className="card-body text-center">
                <i className='fa-solid fa-plus'></i>
                <p className='card-text'>Add your skills </p>
              </div>
            </div>
          </div>
          <div className={` ${PrCss.addSections}`}>
            <div className="card w-100">
              <div className="card-body text-center">
                <i className='fa-solid fa-plus'></i>
                <p className='card-text'> Upload your CV's  </p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  )
}

export default UserProfile
